//
//  ViewController.swift
//  PVLite
//
//  Created by Erik Taylor on 3/3/23.
//
//  poles.txt format as follows:
//  X,Y,comments,poledata,suppdata,VSUMInfo,SRCID,SRCOWN
//  0 = Long | 1 = Lat | 2 = comments | 3 = poledata
//  4 = suppdata | 5 = VSUMInfo | 6 = SRCID | 7 = SRCOWN

import UIKit
import Foundation
import MobileCoreServices
import MapKit

class ViewController: UIViewController, UIDocumentPickerDelegate, MKMapViewDelegate, CLLocationManagerDelegate {
    
    //Map
    @IBOutlet weak var map: MKMapView!
    //Annotations (pins on map)
    var annotations = [MKPointAnnotation()]
    //User Location
    let locationManager = CLLocationManager()
    //Switch for base map
    @IBOutlet weak var switchBaseMap: UISwitch!
    //TextView to display various messages for user
    @IBOutlet weak var lblText: UITextView!

    //Array to store all poles
    var poles: [Pole] = []
    var fileURL: String = ""
    var crosshairView: UIView!
    
    //To keep track of unique inserts
    var insertCounter: Int32 = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Map Settings
        map.showsUserLocation = true
        map.delegate = self
        map.mapType = .standard
        map.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        
        //Ask for user's location
        locationManager.requestWhenInUseAuthorization()
        
        //Track user :O
        locationManager.delegate = self
        locationManager.startUpdatingLocation()
        
        //Follow user >:)
        map.userTrackingMode = .follow
        
        //Add crosshairs to map (off by default)
        crosshairView = UIView(frame: CGRect(x: map.center.x - 15, y: map.center.y - 30, width: 20, height: 20))
        crosshairView.backgroundColor = UIColor.clear
        crosshairView.layer.borderWidth = 2.0
        crosshairView.layer.borderColor = UIColor.red.cgColor
        map.addSubview(crosshairView)
        crosshairView.isHidden = true
        //Label
        lblText.text = "Import a poles file to continue..."
    }
    
    //Show all the pins on the map (to avoid fading in and out based on zoom)
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard let annotation = annotation as? MKPointAnnotation else {
            return nil
        }
        
        let identifier = "annotation"
        var view: MKAnnotationView
        
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) {
            dequeuedView.annotation = annotation
            view = dequeuedView
        } else {
            view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            view.canShowCallout = true
        }
        
        // Disable clustering
        view.clusteringIdentifier = nil
        
        return view
    }
    
    
    //Fires whenever an annotation (pin) is tapped on the map
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        guard let annotation = view.annotation as? MKPointAnnotation else { return }
        if (view.annotation?.title) != nil {
            
            //Loop through pole list to get selected pole using SRCID
            let selectedPole: Pole = getSelectedPole(srcid: annotation.title!)!
            
            if let pinView = view as? MKPinAnnotationView {
                if pinView.pinTintColor == .green{
                    //Already tapped, don't make smaller
                }else{
                    pinView.pinTintColor = .green
                    
                    var frame = pinView.frame
                    frame.size.height *= 0.5 // halve the height of the pin view
                    frame.size.width *= 0.5 // halve the width of the pin view
                    pinView.frame = frame
                }
            }
            performSegue(withIdentifier: "mapToPoleSegue", sender: selectedPole)
        }
    }
    
    
    //Searches array of poles and returns the matched pole based on SRCID
    func getSelectedPole(srcid: String) -> Pole? {
        
        for pole in poles{
            if pole.SRCID == srcid.replacingOccurrences(of: "\"", with: ""){
                //we got 'em
                return pole
            }
        }
        return nil
    }
    
    
    //Sets pole object in PoleDetailsVC
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "mapToPoleSegue" {
            if let pole = sender as? Pole, let poleDetailsViewController = segue.destination as? PoleDetailsViewController {
                poleDetailsViewController.didSendValue = { [weak self] value in
                    self?.didReceiveValue(value)
                }
                poleDetailsViewController.pole = pole
            }
        }
    }
    
    
    //When poledetails screen closes, this method is sent the pole object to update it
    func didReceiveValue(_ value: Pole) {
        lblText.text = "Done editing pole: \(value.SRCID)"
        //Update previously selected pole with current data and update annotation pin
        for pole in poles {
            if pole.SRCID == value.SRCID{
                print("Found the pole")
                //Matched, update the info
                pole.poledata = value.poledata
                pole.comments = value.comments
            }
        }
        //Update the annotation
        for annotation in annotations {
            if annotation.title == "\"" + value.SRCID + "\"" || annotation.title == value.SRCID{
                print("Found the pin")
                annotation.subtitle = value.poledata
                //Matched, update the annotation
                if let annotationView = map.view(for: annotation) {
                    annotationView.setNeedsDisplay()
                }
            }
        }
    }
    
    
    //Switch appearance of map based on switch
    @IBAction func switchBaseMapTap(_ sender: UISwitch) {
        if sender.isOn{
            //Turn on satellite
            map.mapType = .hybrid
        }
        else{
            //Turn on standard
            map.mapType = .standard
        }
    }
    
    
    //Add a new pole to the map
    @IBAction func btnInsertPoleTap(_ sender: Any) {
        
        //Create a pole to insert
        let insertPole = Pole()

        // Get the center point of the map view
        let mapCenterPoint = CGPoint(x: map.bounds.midX, y: map.bounds.midY)

        // Convert the center point to a coordinate
        let centerCoordinate = map.convert(mapCenterPoint, toCoordinateFrom: map)

        // Create an annotation with the center coordinate
        let annotation = MKPointAnnotation()
        annotation.coordinate = centerCoordinate
        

        // Add the annotation to the map view
        map.addAnnotation(annotation)
        
        insertPole.X = annotation.coordinate.longitude
        insertPole.Y = annotation.coordinate.latitude
        insertPole.poledata = ",,,,,,,,,,,,,,,,,,,,"
        insertPole.SRCID = "INSERT\(String(describing: insertCounter))"
        insertPole.comments = ""
        insertPole.SRCOWN = ""
        insertPole.suppdata = ""
        poles.append(insertPole)
        
        annotation.title = insertPole.SRCID
        annotation.subtitle = insertPole.poledata
        annotations.append(annotation)
        
        insertCounter += 1
    }
    
    
    //Presents the files app to let user select the poles.txt file
    @IBAction func btnOpenFiles(_ sender: Any) {
        
        let documentPicker = UIDocumentPickerViewController(documentTypes: [kUTTypePlainText as String], in: .import)
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = false
        present(documentPicker, animated: true, completion: nil)
    }
    
    
    //Reads the poles.txt file and updates the Poles array
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let selectedFileURL = urls.first else {
            return
        }
        
        // Read the contents of the selected file
        do {
            let fileContents = try String(contentsOf: selectedFileURL)
            var stringArr = fileContents.components(separatedBy: CharacterSet.newlines)
            stringArr.removeFirst()
            //print("Selected file contents: \(fileContents)")
            plotCoord(stringArr: stringArr)
            // Do something with the file contents
        } catch {
            print("Error reading file: \(error.localizedDescription)")
        }
        // Dismiss the document picker
        controller.dismiss(animated: true, completion: nil)
    }
    
    
    //Event for if the user does not select a file
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        // User cancelled document picker
        print("Document picker was cancelled by the user")
        // Dismiss the document picker
        controller.dismiss(animated: true, completion: nil)
    }
    
    
    //Add poles to map as well as Poles array:
    func plotCoord(stringArr: [String]){
        //need to loop through and create points based on each line
        var lat: String
        var long: String
        var latDouble: Double!
        var longDouble: Double!
        
        for point in stringArr{
            if point == "" {
                
            }else{
                let tempPole = Pole()
                let tempData = splitCommaDelimitedString(point)
                tempPole.setData(strArr: tempData)
                poles.append(tempPole)
                long = tempData[0]
                lat = tempData[1]
                latDouble = Double(lat)
                longDouble = Double(long)
                
                lblText.text = lblText.text + ("\nLat: " + lat + "   Long: " + long)
                
                let coordinate = CLLocationCoordinate2D(latitude: latDouble, longitude: longDouble)
                
                let annotation = MKPointAnnotation()
                
                annotation.coordinate = coordinate
                annotation.title = tempData[6]
                annotation.subtitle = tempPole.poledata
                annotations.append(annotation)
                
                map.addAnnotation(annotation)
                
                let annotationCoordinate = annotation.coordinate
                let regionRadius: CLLocationDistance = 1000 // meters
                let region = MKCoordinateRegion(center: annotationCoordinate, latitudinalMeters: regionRadius, longitudinalMeters: regionRadius)
                map.setRegion(region, animated: true)
            }
            
        }
        lblText.text = "Pole(s) mapped..."
    }
    
    //Turn on the crosshair based on the switch
    @IBAction func btnInsertTap(_ sender: Any) {
        crosshairView?.isHidden = !(crosshairView?.isHidden ?? true)
    }
    
    
    //Allow user to select and move a pole
    @IBAction func btnMovePoleTap(_ sender: Any) {
        lblText .text = "Select a pole to move..."
    }
    
    //Takes a comma delimited string and returns the String array. Ignores commas inside ""s
    func splitCommaDelimitedString(_ str: String) -> [String] {
        //X,Y,comments,poledata,suppdata,VSUMInfo,SRCID,SRCOWN
        //0 = Long | 1 = Lat | 2 = comments | 3 = poledata | 4 = suppdata | 5 = VSUMInfo | 6 = SRCID | 7 = SRCOWN
        let pattern = #""[^"]*"|[^",]+"#
        let regex = try! NSRegularExpression(pattern: pattern, options: [])
        let matches = regex.matches(in: str, options: [], range: NSRange(str.startIndex..., in: str))
        let parts = matches.map { match -> String in
            let range = Range(match.range, in: str)!
            return String(str[range])
        }
        return parts
    }
    
}




class PoleDetailsViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    //poledata boxes:
    @IBOutlet weak var tbComments: UITextField!
    @IBOutlet weak var tbOwner: UITextField!
    @IBOutlet weak var tbPoleNum: UITextField!
    @IBOutlet weak var tbAttch1: UITextField!
    @IBOutlet weak var tbAttch2: UITextField!
    @IBOutlet weak var tbAttch3: UITextField!
    @IBOutlet weak var tbAttch4: UITextField!
    @IBOutlet weak var tbAttch5: UITextField!
    @IBOutlet weak var tbAttch6: UITextField!
    @IBOutlet weak var tbAttch7: UITextField!
    @IBOutlet weak var tbAttch8: UITextField!
    @IBOutlet weak var tbAttch9: UITextField!
    @IBOutlet weak var tbAttch10: UITextField!
    @IBOutlet weak var tbAttch11: UITextField!
    @IBOutlet weak var tbAttch12: UITextField!
    @IBOutlet weak var tbAttch13: UITextField!
    @IBOutlet weak var tbAttch14: UITextField!
    @IBOutlet weak var tbAttch15: UITextField!
    @IBOutlet weak var tbAttch16: UITextField!
    @IBOutlet weak var tbAttch17: UITextField!
    @IBOutlet weak var tbPoleAttribs: UITextField!
    
    
    @IBOutlet weak var lblPreview: UITextView!
    @IBOutlet weak var lblHeader: UILabel!
    
    @IBOutlet weak var btnTakePicture: UIButton!
    @IBOutlet weak var btnGetDirections: UIButton!
    @IBOutlet weak var btnDone: UIButton!
    @IBOutlet weak var btnDelete: UIButton!
    
    
    //var annotation: MKPointAnnotation?
    var pole: Pole?
    
    weak var currentTextField: UITextField!
    
    var poledata: String?
    var origPoledata: String?
    
    var didSendValue: ((Pole) -> Void)?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let pole = pole {
            lblPreview.text = pole.poledata
            lblHeader.text = pole.SRCID
            
            //Fan out poledata
            poledata = pole.poledata
            origPoledata = poledata
            let pd: [String] = splitPoleData(str: pole.poledata)!
            
            //Assign attacher boxes
            tbComments.text = pole.comments; //tbComments.inputView = UIView()
            tbOwner.text = pd[1]; tbOwner.inputView = UIView()
            //tbPoleNum.text = pd[2]
            tbAttch1.text = pd[2]; tbAttch1.inputView = UIView()
            tbAttch2.text = pd[3]; tbAttch2.inputView = UIView()
            tbAttch3.text = pd[4]; tbAttch3.inputView = UIView()
            tbAttch4.text = pd[5]; tbAttch4.inputView = UIView()
            tbAttch5.text = pd[6]; tbAttch5.inputView = UIView()
            tbAttch6.text = pd[7]; tbAttch6.inputView = UIView()
            tbAttch7.text = pd[8]; tbAttch7.inputView = UIView()
            tbAttch8.text = pd[9]; tbAttch8.inputView = UIView()
            tbAttch9.text = pd[10]; tbAttch9.inputView = UIView()
            tbAttch10.text = pd[11]; tbAttch10.inputView = UIView()
            tbAttch11.text = pd[12]; tbAttch11.inputView = UIView()
            tbAttch12.text = pd[13]; tbAttch12.inputView = UIView()
            tbAttch13.text = pd[14]; tbAttch13.inputView = UIView()
            tbAttch14.text = pd[15]; tbAttch14.inputView = UIView()
            tbAttch15.text = pd[16]; tbAttch15.inputView = UIView()
            tbAttch16.text = pd[17]; tbAttch16.inputView = UIView()
            tbAttch17.text = pd[18]; tbAttch17.inputView = UIView()
            tbPoleAttribs.text = pd[19]; tbPoleAttribs.inputView = UIView()
            
            tbComments.delegate = self
            tbAttch1.delegate = self;tbAttch2.delegate = self;tbAttch3.delegate = self;tbAttch4.delegate = self;
            tbAttch5.delegate = self;tbAttch6.delegate = self;tbAttch7.delegate = self;tbAttch8.delegate = self;
            tbAttch9.delegate = self;tbAttch10.delegate = self;tbAttch11.delegate = self;tbAttch12.delegate = self;
            tbAttch13.delegate = self;tbAttch14.delegate = self;tbAttch15.delegate = self;tbAttch16.delegate = self;
            tbAttch17.delegate = self;tbPoleAttribs.delegate = self;tbOwner.delegate = self;tbPoleNum.delegate = self;
        }
    }
    
    
    //Split pd string into an array and return it
    func splitPoleData(str: String) -> [String]?{
        let poledata: [String] = str.components(separatedBy: ",")
        return poledata
    }
    
    
    //Close the pole details screen
    @IBAction func btnDoneTap(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    //Let user take picture(s) of pole (TODO: Save photo after capture)
    @IBAction func btnTakePicTap(_ sender: Any) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .camera
        present(imagePicker, animated: true, completion: nil)
    }
    
    
    //Opens the selected pole in apple maps
    @IBAction func btnGetDirectsTap(_ sender: Any) {
        //Open apple maps with the selected pole as a destination
        let coordinate = CLLocationCoordinate2D(latitude: (pole?.Y)!, longitude: (pole?.X)!)
        let placemark = MKPlacemark(coordinate: coordinate)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = pole?.SRCID
        mapItem.openInMaps(launchOptions: nil)
    }
    
    
    //Delete the pole (format poledata)
    @IBAction func btnDeleteTap(_ sender: Any) {
        for i in 1...18 {
            // Code to be executed in each iteration of the loop
            if let textField = view.viewWithTag(i) as? UITextField {
                textField.text = ""
            }
        }
        tbOwner.text = ""
        tbComments.text = "DELETE"
        poledata = "DELETE,,,,,,,,,,,,,,,,,,,,"
        lblPreview.text = poledata
    }
    
    
    //Photo stuff
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        //let image = info[.originalImage] as! UIImage
        // Do something with the image
        dismiss(animated: true, completion: nil)
    }
    
    
    //Close the camera if user taps cancel
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    
    //When the user taps one of the attacher boxes, bring up the attachment details view
    func textFieldDidBeginEditing(_ textField: UITextField) {
        //Don't pop up attacher selection for comments and pole number
        if textField == tbComments || textField == tbPoleNum{
            //Do nothing, the keyboard should pop up
        }else{
            NotificationCenter.default.addObserver(self, selector: #selector(didGetNotification(_:)), name: Notification.Name("attacherDetails"), object: nil)
            let attachersTabController = storyboard?.instantiateViewController(identifier: "AttachersTabController") as! AttachersTabController
            attachersTabController.modalPresentationStyle = .popover
            present(attachersTabController, animated: true)
            self.currentTextField = textField
            return
        }
    }
    
    
    //Whenever an attacher value is changed, update the preview label
    func textFieldDidChangeSelection(_ textField: UITextField) {
        updatePDLabel()
    }
    
    
    //Clears the appropriate textfield for the trash button pressed
    @IBAction func clearTextField(sender: UIButton) {
        let textFieldTag = sender.tag - 100 // subtract 100 to get the tag value of the text field
        if let textField = view.viewWithTag(textFieldTag) as? UITextField {
            textField.text = ""
        }
        updatePDLabel()
    }
    
    //Cancels editing of the currently selected pole and returns to map screen
    @IBAction func btnCancelTap(_ sender: Any) {
        poledata = origPoledata
        dismiss(animated: true)
    }
    
    
    //Combine all attach text boxes to create the updated poledata string
    func updatePDLabel(){
        let tempPD: String = "," + (tbOwner.text ?? "") + "," + (tbAttch1.text ?? "") + "," + (tbAttch2.text ?? "") + "," + (tbAttch3.text ?? "") + "," + (tbAttch4.text ?? "") + "," + (tbAttch5.text ?? "") + "," + (tbAttch6.text ?? "") + "," + (tbAttch7.text ?? "") + "," + (tbAttch8.text ?? "") + "," + (tbAttch9.text ?? "") + "," + (tbAttch10.text ?? "") + "," + (tbAttch11.text ?? "") + "," + (tbAttch12.text ?? "") + "," + (tbAttch13.text ?? "") + "," + (tbAttch14.text ?? "") + "," + (tbAttch15.text ?? "") + "," + (tbAttch16.text ?? "") + "," + (tbAttch17.text ?? "") + "," + (tbPoleAttribs.text ?? "")
        lblPreview.text = tempPD
        poledata = tempPD
    }
    
    
    //Receive attacher details here from attacherdetailsview
    @objc func didGetNotification(_ notification: Notification){
        let tempStr = (notification.object as! String?)!
        if notification.name.rawValue == "attacherDetails"{
            self.currentTextField.text = tempStr
        }
    }
    
    
    //Dismiss keyboard on return tap
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            return true
        }
    
    
    //Return the poledata back to the main map screen after editing
    override func viewDidDisappear(_ animated: Bool) {
        
        //Return the pole object back to the main map screen with any changes
        pole?.comments = tbComments.text ?? ""
        pole?.poledata = poledata ?? ""
        
        didSendValue?(pole!)
    }
}







class AttachersTabController: UITabBarController{
    
    
    
    
}



class OwnerSelectionMenu: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate{
    
    public var completionHandler: ((String?) -> Void)?
    
    //Holds the value of the selected attachment
    var tempStr: String = ""
    
    //PickerView for selecting owner code
    @IBOutlet weak var pickerAttachment: UIPickerView!
    
    @IBOutlet weak var lblAttachmentDesc: UILabel!
    
    //Temp data for pickerview
    let pickerData = ["","AT&T","BBTC","BRWN","BTBT","CLNK","CMBC","COOP","CTCO","EJEC","EKEC","ENEC","ESBC","ESPO","EVEC","EWCC","FRTR","GNTL","GVEC","GVTC","HCTC","MCAC","MDEC","MRCC","MUNI","MVEC","OXEA","PHRC","RAYC","RGDC","SBNC","SCTC","SJNC","SWTT","TWCH","TXCC","VLTC ","VRZN"]
    
    let attachmentDesc = ["","AT&T","Big Bend Telephone Company Owned","Brownsville PUB Owned","Border to Border Telephone Owned","CenturyTel of Port Aransas","City of Combes Owned","Co-Op Owned","Central Telephone Co (CLK) Owned Pole","Jackson Electric Coop Owned","Karnes Electric Coop Owned","NUECES ELECTRIC COOPERATIVE","San Bernard Electric Coop Owned","San Patricio Electric Coop Owned","Victoria Electric Coop Owned","Wharton County Coop Owned","Frontier Communications","Ganado Telephone Co Owned","Guadalupe Valley Electric Cooperative","Guadalupe Valley Telephone Cooperative","Hill Country Telephone Owner","City of McAllen Owned","Medina Electric Cooperative Owned","City of Mercedes Owned","Municipal Owned","Magic Valley Elec Coop Owned","OXEA Corporation Owned","City of Pharr Owned","City of Raymondville Owned","City of Rio Grande","City of San Benito Owned","Smartcom Telephone Owned","City of San Juan Owned","Southwest Texas Telephone Company","Time Warner Cable Owned","AEP Texas Central Company","Valley Telephone Company Owned","Verizon Southwest Owned"]
    
    
    
    override func viewDidLoad() {
        //Startup code here
        super.viewDidLoad()
        pickerAttachment.delegate = self
        pickerAttachment.dataSource = self
        view.addSubview(pickerAttachment)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1 // Return the number of components (columns) in the picker view
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count // Return the number of rows in the picker view
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        lblAttachmentDesc.text = attachmentDesc[row]
        tempStr = pickerData[row]
        return pickerData[row] // Return the data for the specified row and component
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        NotificationCenter.default.post(name: Notification.Name("attacherDetails"), object: tempStr)
    }
    
    
}



class TelSelectionMenu: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate{
    
    public var completionHandler: ((String?) -> Void)?
    
    @IBOutlet weak var lblAttachmentDesc: UILabel!
    
    //Holds the value of the selected attachment
    var tempStr: String = ""
    
    //PickerView for selecting Tel code
    @IBOutlet weak var pickerAttachment: UIPickerView!
    
    //Temp data for pickerview
    let pickerData = ["","ATT","ATX","CLK","CLX","CTC","CTX","FTR","FTX","GTL","GVT","LWD","RVR","VTC"]
    
    let attachmentDesc = ["","AT&T","AT&T (outside 3 feet)","Central Telephone Co (CLK)","Central Telephone Co (CLK) Outside of 3 ft","CenturyTel of Port Aransas","CenturyTel of Port Aransas(outside of 3 feet)","Frontier (outside 3 feet)","Frontier Communications","Ganado Telephone Co Attached","Guadalupe Valley Telephone Cooperative","La Ward Telephone Co Attached","Riviera Telephone Co","Valley Telephone Company"]
    
    override func viewDidLoad() {
        //Startup code here
        super.viewDidLoad()
        pickerAttachment.delegate = self
        pickerAttachment.dataSource = self
        view.addSubview(pickerAttachment)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1 // Return the number of components (columns) in the picker view
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count // Return the number of rows in the picker view
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        lblAttachmentDesc.text = attachmentDesc[row]
        tempStr = pickerData[row]
        return pickerData[row] // Return the data for the specified row and component
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        NotificationCenter.default.post(name: Notification.Name("attacherDetails"), object: tempStr)
    }
}



class CLECSelectionMenu: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate{
    
    public var completionHandler: ((String?) -> Void)?
    
    @IBOutlet weak var lblAttachmentDesc: UILabel!
    
    //Holds the value of the selected attachment
    var tempStr: String = ""
    
    //PickerView for selecting Tel code
    @IBOutlet weak var pickerAttachment: UIPickerView!
    
    //Temp data for pickerview
    let pickerData = ["","ALH","BDC","CEL","CLC","CLF","CVT","CCC","XTN","FBL","FRM","GEF","JEF","LVT","LAN","MCL","MBL","CNG","PCC","SCT","TCF","TSP","TWN","TWF","TTC","UNK","VEF","WAN","WLM"]
    
    let attachmentDesc = ["","Alpheus (dba Logix Comm)","BorderComm - Transtelco","Cellco (Verizon DAS-TCC)","CellCo (Verizon)","CenturyLink Fiber","Converged Technologies (dba Gigabit Comm)","Crown Castle NG Central (NextEra)","ExteNet Systems","Fiberlight","Foremost Telecommunications","Guadalupe Electric Coop Fiber","Jackson Electric Fiber","Level 3 Communications LLC","LiveAir Networks","McLeod USA Telecommunications","Mobilitie","New Cingular Wireless PCS","Port of Corpus Christi","Smartcom Telephone","TCC Fiber","Telspirion USA","TELWESTNETWORKS","Time Warner Cable Luling Clec","Transtelco","UNKNOWN ATTACHMENT","Victoria Electric Fiber","WANRack","Williams Communications"]
    
    override func viewDidLoad() {
        //Startup code here
        super.viewDidLoad()
        pickerAttachment.delegate = self
        pickerAttachment.dataSource = self
        view.addSubview(pickerAttachment)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1 // Return the number of components (columns) in the picker view
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count // Return the number of rows in the picker view
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        lblAttachmentDesc.text = attachmentDesc[row]
        tempStr = pickerData[row]
        return pickerData[row] // Return the data for the specified row and component
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        NotificationCenter.default.post(name: Notification.Name("attacherDetails"), object: tempStr)
    }
}
